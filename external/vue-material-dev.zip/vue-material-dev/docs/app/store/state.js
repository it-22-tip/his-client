export default {
  pageTitle: '',
  theme: 'default',
  splashPage: false,
  menuVisible: false
}
