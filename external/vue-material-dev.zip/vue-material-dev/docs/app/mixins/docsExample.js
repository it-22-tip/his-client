export default {
  computed: {
    examples () {
      return this.$options.examples
    }
  }
}
