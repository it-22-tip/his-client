<template>
  <page-container :title="$t('pages.error.title')">

  </page-container>
</template>

<style lang="scss">

</style>

<script>
export default {
  name: 'Error'
}
</script>
