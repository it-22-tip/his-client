<template>
  <page-container centered :title="$t('pages.themes.title')">

  </page-container>
</template>

<script>
  export default {
    name: 'Themes'
  }
</script>
