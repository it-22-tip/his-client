<template>
  <page-container centered :title="$t('pages.themeAdvanced.title')">
    Coming Soon...
  </page-container>
</template>

<script>
  export default {
    name: 'Advanced'
  }
</script>
