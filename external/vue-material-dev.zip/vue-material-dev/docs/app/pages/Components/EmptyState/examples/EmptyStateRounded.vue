<template>
  <md-empty-state
    md-rounded
    md-icon="access_time"
    md-label="Nothing in Snoozed"
    md-description="Anything you snooze will go here until it's time for it to return to the inbox.">
  </md-empty-state>
</template>

<script>
  export default {
    name: 'EmptyStateRounded'
  }
</script>
