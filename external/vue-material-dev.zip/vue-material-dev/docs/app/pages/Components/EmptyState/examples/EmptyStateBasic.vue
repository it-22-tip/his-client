<template>
  <div>
    <md-empty-state
      md-icon="devices_other"
      md-label="Create your first project"
      md-description="Creating project, you'll be able to upload your design and collaborate with people.">
      <md-button class="md-primary md-raised">Create first project</md-button>
    </md-empty-state>
  </div>
</template>

<script>
  export default {
    name: 'EmptyStateBasic'
  }
</script>
