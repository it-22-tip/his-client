<template>
  <div>
    <md-avatar>
      <img src="/assets/examples/avatar.png" alt="Avatar">
    </md-avatar>

    <md-avatar class="md-avatar-icon">
      <md-icon>home</md-icon>
    </md-avatar>

    <md-avatar class="md-avatar-icon md-primary">
      <md-icon>folder</md-icon>
    </md-avatar>

    <md-avatar class="md-avatar-icon md-accent">
      <md-icon>favorite</md-icon>
    </md-avatar>
  </div>
</template>

<script>
export default {
  name: 'Regular'
}
</script>
