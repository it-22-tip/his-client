<template>
  <div>
    Coming Soon...
  </div>
</template>

<script>
  export default {
    name: 'TablePaginationSoon'
  }
</script>
