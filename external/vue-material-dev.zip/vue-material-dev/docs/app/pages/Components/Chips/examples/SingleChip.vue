<template>
  <div>
    <md-chip>Static</md-chip>
    <md-chip class="md-primary" md-deletable>Deletable</md-chip>
    <md-chip class="md-accent" md-clickable>Clickable</md-chip>
    <md-chip md-disabled>Disabled</md-chip>
  </div>
</template>

<script>
export default {
  name: 'SingleChip'
}
</script>
