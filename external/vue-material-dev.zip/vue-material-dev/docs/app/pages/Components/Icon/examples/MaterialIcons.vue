<template>
  <div>
    <div>
      <md-icon>menu</md-icon>
      <md-icon>add</md-icon>
      <md-icon>thumb_up</md-icon>
      <md-icon>verified_user</md-icon>
      <md-icon>home</md-icon>
    </div>

    <div>
      <md-icon>menu</md-icon>
      <md-icon class="md-size-2x">add</md-icon>
      <md-icon class="md-size-3x">thumb_up</md-icon>
      <md-icon class="md-size-4x">verified_user</md-icon>
      <md-icon class="md-size-5x">home</md-icon>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MaterialIcons'
}
</script>
