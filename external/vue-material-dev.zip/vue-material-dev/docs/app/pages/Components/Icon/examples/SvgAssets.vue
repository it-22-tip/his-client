<template>
  <div>
    <div>
      <md-icon md-src="/assets/icon-add.svg" />
      <md-icon md-src="/assets/icon-home.svg" />
      <md-icon md-src="/assets/icon-menu.svg" />
      <md-icon md-src="/assets/icon-thumbs-up.svg" />
      <md-icon md-src="/assets/icon-verified.svg" />
    </div>

    <div>
      <md-icon md-src="/assets/icon-add.svg" />
      <md-icon class="md-size-2x" md-src="/assets/icon-home.svg" />
      <md-icon class="md-size-3x" md-src="/assets/icon-menu.svg" />
      <md-icon class="md-size-4x" md-src="/assets/icon-thumbs-up.svg" />
      <md-icon class="md-size-5x" md-src="/assets/icon-verified.svg" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'SvgAssets'
}
</script>
