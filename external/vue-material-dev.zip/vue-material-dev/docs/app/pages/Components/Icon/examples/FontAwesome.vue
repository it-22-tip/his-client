<template>
  <div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <div>
      <md-icon class="fa fa-bars"></md-icon>
      <md-icon class="fa fa-plus"></md-icon>
      <md-icon class="fa fa-thumbs-up"></md-icon>
      <md-icon class="fa fa-shield"></md-icon>
      <md-icon class="fa fa-home"></md-icon>
    </div>

    <div>
      <md-icon class="fa fa-bars"></md-icon>
      <md-icon class="md-size-2x fa fa-plus"></md-icon>
      <md-icon class="md-size-3x fa fa-thumbs-up"></md-icon>
      <md-icon class="md-size-4x fa fa-shield"></md-icon>
      <md-icon class="md-size-5x fa fa-home"></md-icon>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FontAwesome'
}
</script>
