export default {
  code: {
    copyMessage: 'Code copied!',
    copy: 'Copy'
  }
}
