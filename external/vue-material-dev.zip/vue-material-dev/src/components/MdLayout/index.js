import './layout.scss'

export default Vue => {

}
