import './elevation.scss'

export default Vue => {
}
